|Ref|Qty|Description|Digikey PN|
|---|---|-----------|------|
|BAT1|1|CR1220 BATTERY HOLDER SMT FLATPIN|BK-916-CT-ND|
|LED1|1|LED RED DIFF 5MM ROUND T/H|1125-1188-ND|


